//
//  ViewController.swift
//  VideoDemo
//
//  Created by Michael Mayer on 7/4/16.
//  Copyright © 2016 Michael M. Mayer. All rights reserved.
//

import Cocoa
import AVFoundation
import AVKit

class ViewController: NSViewController {
	@IBOutlet weak var avPlayer: AVPlayerView!

	override func viewDidLoad() {
		super.viewDidLoad()
		let tempFilepath = "/tmp/tmp.mp4"  // temporary filepath for the pipe(must have the correct filetype)
		
		// sample video from which we createq the NSData objectaa
		let movieData = NSData(contentsOfFile: <#movieFilePath#>)  // for demonstration purposes, supply path to your video

		// In a background thread, create the pipe and write to it
		dispatch_async(dispatch_get_global_queue(0,0)) {
			mkfifo(tempFilepath, 0666)
			movieData?.writeToFile(tempFilepath, atomically: true)
		}
		
		RunAfterDelay(0.5) { [unowned self] in
			// load the video through the named pipe
			let player = AVPlayer(URL: NSURL(fileURLWithPath: tempFilepath))
			
			//set up the video player
			self.avPlayer.controlsStyle = .Floating
			self.avPlayer.showsFullScreenToggleButton = true
			self.avPlayer.player = player
			
			player.play()
			
			unlink(tempFilepath)  // removes the temporary filepath
		}
	}

	/** Runs a closure on the main queue after a specified number of seconds
	- Parameter delay: the number of seconds before the closure is executed
	- Parameter block: the closure to be executed 
	- Author: Paul Hudson */
	func RunAfterDelay(delay: NSTimeInterval, block: dispatch_block_t) {
		let time = dispatch_time(DISPATCH_TIME_NOW, Int64(delay * Double(NSEC_PER_SEC)))
		dispatch_after(time, dispatch_get_main_queue(), block)
	}
}